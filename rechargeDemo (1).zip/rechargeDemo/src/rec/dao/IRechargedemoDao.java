package rec.dao;

import rec.bean.RechargedemoBean;
import rec.exception.RechargedemoException;

public interface IRechargedemoDao 
{
	public int storeDetails(RechargedemoBean rb) throws RechargedemoException;
	public int storerechargeid(RechargedemoBean rb) throws RechargedemoException;

}
