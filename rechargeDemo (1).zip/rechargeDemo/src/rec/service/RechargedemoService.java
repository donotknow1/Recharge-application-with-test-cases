package rec.service;

import rec.bean.RechargedemoBean;
import rec.dao.IRechargedemoDao;
import rec.dao.RechargedemoDao;
import rec.exception.RechargedemoException;


public class RechargedemoService implements IRechargedemoService{

	IRechargedemoDao rdao=null;
	
	
	@Override
	public int storeDetails(RechargedemoBean rb) throws RechargedemoException 
	{
		rdao=new RechargedemoDao();
		return rdao.storeDetails(rb);
	}


	@Override
	public String validateamount(int amount) 
	{
		String plan = null;
		
		if(amount==99)
		{
			plan="RC99";
			
		}
		
		else if(amount==199)
		{
			plan="RC199";
		}
		else if(amount==299)
		{
			plan="RC299";
		}
		else
			System.out.println("enter valid amount");

		return plan;
	}


	@Override
	public int storerechargeid(RechargedemoBean rb) throws RechargedemoException {
		int rechid=0;
		rdao=new RechargedemoDao();
		rechid=rdao.storerechargeid(rb);
		
		
		return rechid;
	}

}
