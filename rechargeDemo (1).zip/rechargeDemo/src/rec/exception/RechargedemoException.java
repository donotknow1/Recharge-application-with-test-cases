package rec.exception;

public class RechargedemoException extends Exception
{
	public RechargedemoException()
	{
		
	}

	public RechargedemoException(String msg)
	{
		super(msg);
	}
}
